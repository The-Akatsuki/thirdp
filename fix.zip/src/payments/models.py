# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.conf import settings

# Create your models here.

class paymentsDetails(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL,
                                primary_key=True)
    nameOnCard = models.CharField(max_length=250, null=True,verbose_name="name On Card")
    cardNumber = models.CharField(max_length=20,null=True,verbose_name="card Number")
    expirationDateMM = models.IntegerField(verbose_name="expiration Date (MM)")
    expirationDateYY = models.IntegerField(verbose_name="expiration Date (YY)")
    cvcCode = models.IntegerField(verbose_name="CVV Code")
    address = models.TextField(null=True,verbose_name="address")
    city = models.CharField(max_length=250, blank=True,verbose_name="City")
    state = models.CharField(max_length=250, blank=True,verbose_name="state")
    zipCode = models.CharField(max_length=250, blank=True,verbose_name="zip Code")


